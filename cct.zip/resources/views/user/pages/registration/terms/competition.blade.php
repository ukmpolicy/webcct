<b>PERATURAN LOMBA :</b>
<ol>
    <li>Semua lomba dilaksanakan ditempat.</li>
    <li>Peserta terbatas.</li>
    <li>Penentuan nomor meja peserta dilakukan melalui undian yang akan diambil pada saat registrasi ulang </li>dilakukan.
    <li>Pengumpulan hasil lomba dilakukan saat lomba telah berakhir.</li>
    <li>Pada saat recheking peserta diwajibkan membawa bukti transfer dan mendaftar ulang pada pihak penyelenggara.</li>
    <li>Bila terdapat ketidaksesuaian, peserta yang bersangkutan akan di diskualifikasi dan dinyatakan gugur.</li>
    <li>Peserta wajib mengenakan pakaian rapi dan sopan serta memakai sepatu.</li>
    <li>Peserta menggunakan kemeja(pria) mengenakan celana Panjang. Peserta (wanita) mengenakan celana bahan panjang atau rok panjang (tidak boleh diatas lutut) dan juga mengenakan jilbab dengan baju yang sopan.</li>
    <li>Peserta yang berhalangan hadir tidak dapat digantikan peserta lain.</li>
    <li>Peserta diharapkan mengaktifkan mode senyap pada alat elektronik yang dibawa pada saat lomba </li>berlangsung.
    <li>Peserta tidak diperkenankan melakukan kecurangan dalam bentuk apapun.</li>
    <li>Jika sebelum,selama,atau sesudah perlombaan pihak penyelenggara menemukan adanya kecurangan yang </li>dilakukan peserta, maka peserta tersebut akan didiskualifikasi atau dinyatakan gugur.
    <li>Peserta tidak diperkenankan melakukan segala bentuk tindakan yang bersifat menghambat jalannya </li>perlombaan.
    <li>Keputusan dewan juri adalah mutlak dan tidak dapat diganggu gugat.</li>
    <li>Peserta tidak boleh merusak peralatan yang telah disediakan oleh panitia.</li>
    <li>Dilarang membawa sajam(senjata tajam), senpi(senjata api), narkotika, dan sejenisnya.</li>
    <li>Untuk hal-hal lainnya akan diberitahukan sebelum perlombaan dimulai.</li>
</ol>

<b>PERSYARATAN DAN KETENTUAN LOMBA DESIGN POSTER:</b>
<ol>
    <li>Peserta merupakan siswa/i aktif SMA/SMK sederajat dan mahasiswa/i aktif.</li>
    <li>Bagi siswa/i aktif dapat menunjukkan KTS(kartu tanda siswa)/ surat aktif siswa, dan Untuk mahasiswa/i </li>melampirkan bukti yang menunjukkan umur tidak melibihi 20 tahun.
    <li>Peserta adalah perorangan (individu).</li>
    <li>Peserta lomba hanya diperbolehkan membuat 1 karya saja.</li>
    <li>Karya asli peserta, bukan meniru/menjiplak desain yang sudah ada</li>
    <li>Panitia tidak bertanggung jawab apabila ada klaim dari pihak lain atas ke-tidak orisinilan karya atau </li>plagiarisme.
    <li>Tidak mengandung unsur pornografi dan isu SARA</li>
    <li>Desain poster belum pernah dipublikasikan sebelumnya.</li>
    <li>Hak Cipta atas karya yang ditetapkan sebagai pemenang menjadi sepenuhnya milik UKM-POLICY.</li>
    <li>Keputusan penetapan pemenang tidak dapat diganggu gugat.</li>
    <li>Peserta di anggap mengikuti lomba apabila sudah memenuhi segala administrasi.</li>
</ol>
       
<b>ALUR PERLOMBAAN DESIGN POSTER:</b>
<ol>
    <li>Peserta melakukan pendaftaran pada tanggal yang telah ditentukan.</li>
    <li>Membayar sesuai harga yang ditentukan.</li>
    <li>Peserta mengikuti TM/pembekalan pada tanggal 28 february.</li>
    <li>Peserta mengikuti lomba pada tanggal dan jam yang telah ditentukan.</li>
    <li>Peserta mendesain ditempat sampai pukul 12.00.</li>
    <li>Rechecking ditutup 30 menit sebelum lomba dimulai.</li>
    <li>Panitia membuka acara dan membacakan peraturan yang berlaku</li>
    <li>Bel akan dibunyikan sebagai tanda waktu mulai dan waktu habis.</li>
</ol>

<b>PERSYARATAN DAN KETENTUAN LOMBA LINUX SERVER:</b>
<ol>
    <li>Peserta merupakan siswa/i aktif SMA/SMK sederajat.</li>
    <li>Bagi siswa/i aktif dapat menunjukkan KTS(kartu tanda siswa)/ surat aktif siswa.</li>
    <li>Peserta adalah perorangan (individu).</li>
    <li>Peserta lomba hanya diperbolehkan mensetting linux ditempat saja.</li>
    <li>Keputusan penetapan pemenang tidak dapat diganggu gugat.</li>
    <li>Peserta di anggap mengikuti lomba apabila sudah memenuhi segala administrasi.</li>
</ol>

<b>ALUR PERLOMBAAN LINUX SERVER :</b>
<ol>
    <li>Peserta melakukan pendaftaran pada tanggal yang telah ditentukan.</li>
    <li>Peserta mengikuti TM/pembekalan pada tanggal 28 february.</li>
    <li>Peserta mengikuti lomba pada tanggal dan jam yang telah ditentukan.</li>
    <li>Rechecking ditutup 30 menit sebelum lomba dimulai.</li>
    <li>Panitia membuka acara dan membacakan peraturan yang berlaku</li>
    <li>Bel akan dibunyikan sebagai tanda waktu mulai dan waktu habis.</li>
</ol>




<b>PERSYARATAN DAN KETENTUAN LOMBA TYPING SPEED:</b>
<ul type="dash">
    <li>Peserta merupakan siswa/i aktif SMA/SMK sederajat.</li>
    <li>Bagi siswa/i aktif dapat menunjukkan KTS(kartu tanda siswa)/ surat aktif siswa.</li>
    <li>Peserta adalah perorangan (individu).</li>
    <li>Panitia menyiapkan keyboard eksternal untuk setiap peserta</li>
    <li>Software akan disiapkan oleh panitia maka peserta dilarang memakai software sendiri</li>
    <li>Peserta mulai mengetik setelah aba-aba dari panitia</li>
    <li>Peserta wajib mengangkat tangan jika sudah selesai mengetik</li>
    <li>Peserta di anggap mengikuti lomba apabila sudah memnuhi segala administrasi.</li>
</ul>

<b>ALUR PERLOMBAAN TYPING SPEED:</b>
<ol>
    <li>Peserta melakukan pendaftaran pada tanggal yang telah ditentukan.</li>
    <li>Peserta mengikuti TM/pembekalan pada tanggal 28 february.</li>
    <li>Peserta mengikuti lomba pada tanggal dan jam yang telah ditentukan.</li>
    <li>Rechecking ditutup 30 menit sebelum lomba dimulai.</li>
    <li>Panitia membuka acara dan membacakan peraturan yang berlaku</li>
    <li>Bel akan dibunyikan sebagai tanda waktu mulai dan waktu habis.</li>
</ol>